from django.contrib import admin

from .models import *

admin.site.register(LoginPage)
admin.site.register(Signup)
admin.site.register(Contact)
admin.site.register(RegisterNgo)
# admin.site.register(Order)
# admin.site.register(OrderItem)
# admin.site.register(ShippingAddress)


